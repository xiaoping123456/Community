// 配置项目的请求基准路径
axios.defaults.baseURL = 'http://127.0.0.1:8888'

// 声明请求拦截器
axios.interceptors.request.use(function (config) {
  // 在发送请求之前做些什么
  // 形参中的 config，是每次请求时候的配置选项，里面记录着这次请求对应的：
  // method、url、根路径、headers 请求头
  // if (config.url.indexOf('/my') !== -1) {
  //   // 如果请求的 URL 地址中，包含 /my 则为当前的请求头添加 Authorization 字段
  //   config.headers.Authorization = localStorage.getItem('token')
  // }

  return config
}, function (error) {
  // 对请求错误做些什么
  return Promise.reject(error)
})

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
  // 2xx 范围内的状态码都会触发该函数。
  // 对响应数据做点什么
  return response
}, function (error) {
  // 超出 2xx 范围的状态码都会触发该函数
  console.log(error.response)
  // 1. 判断 '响应状态码' 是否等于 401
  // 2. 如果是，则清空 token，并跳转到 '登录页'
  if (error.response.status === 401) {
    // 清空无效的 token
    localStorage.removeItem('token')
    location.href = '/login.html'
  }

  // 对响应错误做点什么
  return Promise.reject(error)
})
