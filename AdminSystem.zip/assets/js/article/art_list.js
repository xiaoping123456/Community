$(function () {
  // 定义一个查询的参数对象，将来请求数据的的时候，需要将请求参数对象提交到服务器
  var listParams = {
    pagenum: 1, // 页码值，默认氢气第一页的数据
    pagesize: 5, // 每页显示几条数据，默认每页显示 2 条
    cate_id: '', // 文章类的 Id
    state: '' // 文章的发布状态
  }

  // 调用获取文章列表数据的方法
  getArticleList(listParams)

  // 调用获取文章分类数据的方法
  getCateList()

  // 实现筛选功能
  $('#form-search').on('submit', function (e) {
    e.preventDefault()

    // 获取表单中选中项的值
    var cate_id = $('#cate_id').val()
    var state = $('#state').val()

    // 为查询参数对象 listParams 中对应的属性赋值
    listParams.cate_id = cate_id
    listParams.state = state

    // 根据最新的筛选条件，重新渲染表格的数据
    getArticleList()
  })

  // 定义渲染分页的方法
  function renderPage(total) {
    // 调用 laypage.render() 方法来渲染分页的结构
    layui.laypage.render({
      elem: 'pageBox', // 分页容器的 Id
      count: total, // 总数据条数
      limit: listParams.pagesize, // 每页显示几条数据
      curr: listParams.pagenum, // 设置默认被选中的分页
      layout: ['count', 'limit', 'prev', 'page', 'next', 'skip'],
      limits: [5, 10, 15],
      // obj: 当前分页的所有选项值
      // first: 返回布尔值，是否首次，一般用于初始加载的判断
      jump: function (obj, first) {
        //obj包含了当前分页的所有参数，比如：
        // console.log(obj.curr) // 得到当前页，以便向服务端请求对应页的数据
        // console.log(obj.limit) // 得到每页显示的条数

        listParams.pagenum = obj.curr
        listParams.pagesize = obj.limit

        if (!first) {
          getArticleList(listParams)
        }
      }
    })
  }

  // 获取文章列表数据的方法
  function getArticleList() {
    axios({
      method: 'GET',
      url: '/blog/allBlogs',
      params: listParams
    }).then(function (res) {
      console.log(res)
      if (res.data.code === 0) {
        return layer.msg('获取文章列表失败！')
      }

      var articleList = []
      console.log(res.data.list.length)
      if (res.data.list.length === 0) return $('tbody').html(articleList)

      res.data.list.forEach(function (item) {
        articleList.push(`
        <tr>
          <td>${item.blogName}</td>
          <td>${dayjs(item.pubdate).format('YYYY-MM-DD HH:mm:ss')}</td>
          <td>${item.visits}</td>
          <td>
            <button type="button" class="layui-btn layui-btn-xs btn-edit" data-id="${item.id}">查看详情</button>
            <button type="button" class="layui-btn layui-btn-danger layui-btn-xs btn-delete" data-id="${item.id}">删除</button>
          </td>
        </tr>
      `)
        $('tbody').html(articleList)
      })

      // 渲染分页
      renderPage(res.data.total)
    })
  }

  // 获取文章分类数据的方法
  function getCateList() {
    axios({
      method: 'GET',
      url: '/my/cate/list'
    }).then(function (res) {
      if (res.data.code !== 0) {
        return layer.msg('获取分类列表失败')
      }

      const rows = []
      res.data.data.forEach(item => {
        rows.push(`<option value="${item.id}">${item.cate_name}</option>`)
      })

      $('#cate_id').append(rows)
      layui.form.render('select')
    })
  }

  // 删除文章功能
  $('tbody').on('click', '.btn-delete', function () {
    // 获取到文章的 id
    var id = $(this).attr('data-id')
    // 获取删除按钮的个数
    var len = $('.btn-delete').length

    console.log(len)

    // 询问用户是否要删除数据
    layer.confirm('确认删除?', { icon: 3, title: '提示' }, function (index) {

      axios({
        method: 'POST',
        url: '/blog/deleteBlog',
        params: { id: id }
      }).then(function (res) {
        console.log(res)
        if (res==false) {
          return layer.msg('删除文章失败！')
        }
        layer.msg('删除文章成功！')

        if (len === 1) {
          // 如果 len 的值等于1，证明删除完毕之后，页面上就没有任何数据了
          // 页码值最小必须是 1
          listParams.pagenum = listParams.pagenum === 1 ? 1 : listParams.pagenum - 1
        }

        getArticleList()
      })

      layer.close(index)
    })
  })

  // 查看详情功能
  $('tbody').on('click', '.btn-edit', function () {
    // 获取到文章的 id
    var id = $(this).attr('data-id')

    // window.location.href = `/article/art_pub.html?id=${id}`

    // window.parent.highlight('发表文章')

    //跳转到故事详情页
    window.open("http://localhost:8888/blogInfo/"+id); 

  })
})