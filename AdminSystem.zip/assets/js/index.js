$(function () {
  // 调用获取用户信息的方法
  getUserInfo()

  // 导入 layui 方法
  var layer = layui.layer

  // 给 a 标签绑定点击事件
  $('#btnLogout').on('click', function () {
    // 提示用户是否确认退出
    layer.confirm('确认退出登录?', { icon: 3, title: '提示' }, function (index) {
      console.log(index)
      // 1. 清空本地存储的 token
      localStorage.removeItem('token')
      // 2. 重新跳转到登录页面
      location.href = '/login.html'

      layer.close(index);
    })
  })
})

// 获取用户信息的方法
function getUserInfo () {
  axios({
    method: 'GET',
    url: '/my/userinfo'
  }).then(function (res) {
    // 如果数据获取成功，调用渲染用户信息的方法
    if (res.data.code === 0) {
      renderName(res.data.data)
    }
  })
}

// 渲染用户的信息
function renderName (user) {
  // 获取用户的名称
  var name = user.nickname || user.username

  var first = name[0].toUpperCase()
  $('.text-avatar').html(first).show(0)
}

// 定义切换高亮的函数
function highlight(kw) {
  $('dd').removeClass('layui-this')
  $(`dd:contains("${kw}")`).addClass('layui-this')
}
